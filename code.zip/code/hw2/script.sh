#!/bin/bash

cd /code
gcc student_src.c -o student_exe
./student_exe << INPUTS > student_output
abc
123
 
abc 123
exit
INPUTS
