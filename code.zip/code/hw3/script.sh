#!/bin/bash

cd /code
gcc msh.c -o msh
gcc student_src.c -o student_exe
./msh << INPUTS > output
ls
pwd
wc -l fake_file
ls -l fake_dir/fake_text.txt
today
topramen
exit
INPUTS

./student_exe << INPUTS > student_output
ls
pwd 
wc -l fake_file
ls -l fake_dir/fake_text.txt
today
topramen
exit
INPUTS
