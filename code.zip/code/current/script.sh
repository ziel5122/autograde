#!/bin/sh

cd /code

gcc msh.c -o msh

./student_exe << INPUTS > student_output
ls
pwd
cd fake_dir
pwd
wc -l foo.foo
cd ..
pwd
cd
pwd
exit
INPUTS

./student_exe ls_in >> student_output

./msh << INPUTS > output
ls
pwd
cd fake_dir
pwd
wc -l foo.foo
cd ..
pwd
cd
pwd
exit
INPUTS

./msh ls_in >> output
